# etl_package/etl_package/__init__.py
# swiftetl/swiftetl/__init__.py

from .etl_pipeline import ETLPipeline

